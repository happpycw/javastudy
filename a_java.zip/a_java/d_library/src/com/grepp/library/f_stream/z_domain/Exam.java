package com.grepp.library.f_stream.z_domain;

public record Exam(
    String subject,
    String name,
    Integer score
) {

}
