package com.grepp.exception.custom;

public class CommonException extends RuntimeException {

    public CommonException(String message) {
        super(message);
    }
}
