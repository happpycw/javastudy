package com.grepp.exception.coffee;

public class Run {

    public static void main(String[] args) {
        Coffee coffee = new Coffee();
        coffee.provide();
    }

}
