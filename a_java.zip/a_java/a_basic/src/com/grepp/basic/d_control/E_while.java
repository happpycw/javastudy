package com.grepp.basic.d_control;

import java.nio.file.attribute.UserDefinedFileAttributeView;

public class E_while {
    // NOTE DE01 while
    // while(조건식) 코드블록
    // 조건식이 참이면 코드블록을 반복해서 실행
    public static void main(String[] args) {
        pracWhile();
    }

    public static void pracWhile(){
        // 5번만 반복하는 반복문
        int i = 0;
        while(i < 5){
            System.out.println("으아아아아~!");
            i++;
        }
    }
}
