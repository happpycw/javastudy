package com.grepp.oop.a_modifier.test;

import com.grepp.oop.a_modifier.A_modifier;

public class Run {

    public static void main(String[] args) {
        A_modifier.publicMethod();
    }

}
