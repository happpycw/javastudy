package com.grepp.oop.a_modifier;

public class Run {

    public static void main(String[] args) {
        A_modifier.publicMethod();
        A_modifier.protectedMethod();
        A_modifier.callPrivateMethod();
    }
}
