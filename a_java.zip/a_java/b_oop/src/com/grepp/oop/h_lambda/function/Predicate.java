package com.grepp.oop.h_lambda.function;

public interface Predicate<T> {
    boolean test(T t);
}
