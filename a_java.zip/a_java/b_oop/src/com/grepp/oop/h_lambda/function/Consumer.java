package com.grepp.oop.h_lambda.function;

public interface Consumer<T> {

    void accept(T t);

}
