package com.grepp.oop.h_lambda.function;

public interface Supplier<T> {

    T get();

}
