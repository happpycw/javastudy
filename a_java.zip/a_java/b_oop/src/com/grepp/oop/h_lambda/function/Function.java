package com.grepp.oop.h_lambda.function;

public interface Function<T, R> {

    R apply(T arg, T arg2);

}
