package com.grepp.oop.b_init;

public class Run {
    public static void main(String[] args) {
        A_init init = new A_init("하명도");
        //A_init.loadClass();
    }
}
