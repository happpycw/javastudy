package com.grepp.oop.f_interface;

public interface Communicable {
    void send();
    void receive();
}
