package com.grepp.oop.d_inheriteance.b_overload;

public class Run {

    public static void main(String[] args) {
        A_overloading overloading = new A_overloading();
        double res = overloading.plus(10.0, 20.0, 1,2,3,4,5,6,7,8,9,11,12,13,14,15);
        System.out.println(res);
    }
}
